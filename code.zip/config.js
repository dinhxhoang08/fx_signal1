module.exports = {
    telegram_token: '',
    telegram_chatid: '',
	browser_path: '/usr/bin/google-chrome-stable',   //  /snap/bin/chromium
    fb_url: process.env.fb_url,
    symbol: process.env.symbol||'XAUUSD',
    symbols: ['XAUUSD','BTCUSD','EURUSD','GBPUSD'],
    name: 'tv_technicals',
};
