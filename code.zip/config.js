module.exports = {
    telegram_token: '',
    telegram_chatid: '',
	browser_path: '/usr/bin/google-chrome-stable',   //  /snap/bin/chromium
    fb_url: process.env.fb_url,
    CLOUDFLARE_WORKER_URL: process.env.CLOUDFLARE_WORKER_URL||'https://your-cloudflare-worker-url/update',
    symbol: process.env.symbol||'XAUUSD',
    symbols: ['XAUUSD','BTCUSD','EURUSD','GBPUSD'],
    name: 'tv_technicals',
};
