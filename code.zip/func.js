'use strict';

const https = require('https');
const puppeteer = require('puppeteer');
const _ut = require('./util');
const cfg = require('./config');

// Giả lập việc thay đổi dữ liệu trong DB
function update_data_to_worker(path,newData) {
    return new Promise((resolve)=>{
        
        const options = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        };

        const req = https.request(cfg.CLOUDFLARE_WORKER_URL+'/'+path, options, (res) => {
            console.log(`STATUS: ${res.statusCode}`);
            console.log(`HEADERS: ${JSON.stringify(res.headers)}`);
            res.setEncoding('utf8');
            res.on('data', (chunk) => {
                console.log(`BODY: ${chunk}`);
            });
            res.on('end', () => {
                console.log('No more data in response.');
                resolve();
            });
        });

        req.on('error', (e) => {
            console.error(`problem with request: ${e.message}`);
            resolve();
        });

        // Gửi dữ liệu cập nhật tới Cloudflare Worker
        req.write(JSON.stringify(newData));
        req.end();

        console.log('Đã gửi thông báo cập nhật dữ liệu tới Cloudflare Worker.');
    });
}
async function fetch_news() {
    var browser;
    try {
        browser = await puppeteer.launch({
            executablePath: cfg.browser_path,
            headless: true,
            args: [
                '--no-sandbox', '--disable-setuid-sandbox','--disable-dev-shm-usage',
            ],
        });
        const page = await browser.newPage();
        await page.goto('https://www.forexfactory.com/',{waitUntil: 'networkidle2'});
        await _ut.sleep(2000);
        var events = await page.evaluate(async ()=>{
            function sleep(){
                return new Promise((resolve)=>{
                    setTimeout(resolve,1000);
                })
            }
            var i=0;
            while(!window.calendarComponentStates && i++<20) {
                await sleep();
            }
            if(window.calendarComponentStates) {
                var k=Object.keys(window.calendarComponentStates)[0];
                return window.calendarComponentStates[k].days[0].events;
            }
        });
        var maxTm=0, maxTmTitle,it, result=[];
        if(events)
        for(let i=0;i<events.length;i++) {
            it = events[i];
            //"Medium Impact Expected",
            if(["High Impact Expected"].includes(it.impactTitle) && it.timeLabel && (it.timeLabel.endsWith('am')||it.timeLabel.endsWith('pm'))) {
                if(maxTm<it.dateline) {
                    maxTm=it.dateline;
                    maxTmTitle = it.timeLabel;
                }
                if(it.currency=='USD' && !JSON.stringify(result).includes(''+it.dateline)) result.push([it.dateline,it.timeLabel]);
            }
        }
        
        await page.close();
        await browser.close();
        console.log(result);
        
        return result;
    }
    catch(e){
        console.log(e);
        if(browser) await browser.close();
        _ut.telegram('fetch_news:'+e.message);
    }
}
async function detect_trend(symbol) {
    var browser;
    try {
        var url = `https://www.tradingview.com/symbols/${symbol}/technicals/`;
        browser = await puppeteer.launch({
            //browser: 'firefox',
            executablePath: cfg.browser_path,
            headless: true,
            args: [
                '--no-sandbox', '--disable-setuid-sandbox','--disable-dev-shm-usage',
            ],
        });
        const page = await browser.newPage();

        await page.goto(url, { waitUntil: 'domcontentloaded' }); // Wait for network to be idle

        //const content = await page.content(); // Get the fully rendered HTML
        //console.log(content);

        // Example: Extracting text from a specific element
        const title = await page.$eval('h1', element => element.textContent);
        console.log('Page Title:', title);

        var side=await page.evaluate(async ()=>{
            function hq_sleep(tm) {
                return new Promise ((resolve)=>{
                    setTimeout(resolve,tm);
                });
            }
            function hq_random(a,b) {
                return Math.floor(Math.random() * b) + a;
            }
            function getSide() {
                var ee=$('div[style*="--recommendation-degrees"]'), sell=0,buy=0;
                for(let i=0;i<ee.length;i++) {
                    let deg = parseFloat(ee.eq(i).css('--recommendation-degrees').replace('deg'));
                    if(deg>-60) buy++;
                    if(deg<-120) sell++;
                }
                //if(buy>0||sell>0) return buy>sell? 'BUY':'SELL';
                return {buy,sell};
            }
            var buy=0,sell=0,tf=['1m','5m','15m','30m','1h'];
            //1m
            for(let i=0;i<tf.length;i++) {
                try{
                    $(`button[id="${tf[i]}"]`).click();
                    await hq_sleep(hq_random(1600,2000));
                    let s=getSide();
                    buy+=s.buy;
                    sell+=s.sell;
                }
                catch(e){console.log(e)}
            }
            //return buy>sell? 'BUY': (sell>buy? 'SELL':'');
            return {buy,sell}
        });
        await page.close();
        await browser.close();

        console.log(side);

        return side.buy-side.sell>=2? 'BUY': (side.sell-side.buy>=2? 'SELL':'');
    }
    catch(e){
        console.log(e);
        if(browser) await browser.close();
        _ut.telegram('detect_trend:'+e.message);
    }
}

//detect_trend('https://www.tradingview.com/symbols/XAUUSD/technicals/');
//@deprecated
async function save_side(symbol,side) {
    //if(!side) return;
    var dt=_ut.parseJSON(await _ut.fb_get(cfg.name+'/'+symbol),{});
    if(dt) {
        if(!dt.start||dt.side!=side) dt.start = _ut.timestamp();
        dt.side = side;
        dt.time = _ut.timestamp();
    }
    else {
        dt = {
            start: _ut.timestamp(),
            time: _ut.timestamp(),
            side,
        };
    }
    await _ut.fb_set(cfg.name+'/'+symbol,dt);
}
async function crawl_trend(symbol) {
    var side = await detect_trend(symbol), k=`${symbol}_side`;
    //await save_side(symbol, side);
    if(_ut.getVal(k)!=side) {
        _ut.setVal(k, side);
        await update_data_to_worker('update',{
            start: _ut.timestamp(),
            time: _ut.timestamp(),
            side: side||'',
            symbol,
        });
    }
}
async function crawl_news() {
    var lastTm = _ut.getVal('check_tm_news');
    if(lastTm && _ut.timestamp()-lastTm<2*60*60) return;
    _ut.setVal('check_tm_news',_ut.timestamp());

    var news = await fetch_news();
    if(news && JSON.stringify(news)!=JSON.stringify(_ut.getVal('news',[]))) {
        _ut.setVal('news', news);
        await update_data_to_worker('news',{
            news
        });
    }
}
module.exports = {
    detect_trend,save_side,crawl_trend,fetch_news,crawl_news,
};