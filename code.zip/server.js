'use strict';
const express = require('express');
const cron = require('node-cron');
const _ut = require('./util');
const _fn = require('./func');
const cfg = require('./config');

_ut.initTrackErrors();

const app = express();
const port = process.env.PORT || 3000;

// Middleware và các route Express
app.get('/', (req, res) => {
    res.send('Web server đang hoạt động!');
});

// Hàm chứa logic của tác vụ bạn muốn chạy
async function runScheduledTask() {
    console.log('Bắt đầu tác vụ định kỳ...');
    await _fn.crawl_trend(cfg.symbol);
}

cron.schedule('*/5 * * * *', () => {
    runScheduledTask();
});

// Lắng nghe các yêu cầu HTTP để giữ cho server luôn hoạt động
app.listen(port, () => {
    console.log(`Server đang lắng nghe tại http://localhost:${port}`);
});
