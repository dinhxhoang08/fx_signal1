'use strict';
const express = require('express');
const cron = require('node-cron');
const _ut = require('./util');
const _fn = require('./func');
const cfg = require('./config');

_ut.initTrackErrors();

const app = express();
const port = process.env.PORT || 3000;

// Middleware và các route Express
app.get('/', (req, res) => {
    res.send('Web server đang hoạt động!');
});

// Hàm chứa logic của tác vụ bạn muốn chạy
async function runScheduledTask() {
    if(!_ut.getVal('running_task')) {
        _ut.setVal('running_task',1);
        console.log('Bắt đầu tác vụ định kỳ...');
        //crawl news
        await _fn.crawl_news();

        //await _fn.crawl_trend(cfg.symbol);
        for(let i=0;i<cfg.symbols.length;i++) {
            await _fn.crawl_trend(cfg.symbols[i]);
            await _ut.sleep(200);
        }
        _ut.delVal('running_task');
    }
}

cron.schedule('*/2 * * * *', () => {
    runScheduledTask();
});

// Lắng nghe các yêu cầu HTTP để giữ cho server luôn hoạt động
app.listen(port, () => {
    console.log(`Server đang lắng nghe tại http://localhost:${port}`);
});
