'use strict';

const fs = require('fs');
const axios = require('axios');
const cfg = require('./config');

var __data={}; global.__data=__data;
function setVal(k, v) {
  if(typeof k=='string' && typeof v!='undefined') __data[k]=v;
    if(typeof k=='object') __data = Object.assign(__data, k);
    else return __data[k];
}
function setValIfNot(k,v) {
  var v0=getVal(k,null);
  if(v0===null) setVal(k,v);
}
function getVal(k, v,noempty) {
  return typeof __data[k]!='undefined' && (noempty? __data[k]: true) ? __data[k]: v;
}
function delVal(k){
  if(Array.isArray(k)) k.forEach(v=>{delete __data[v]});
  else delete __data[k];
}

function isNum(n){
    if(typeof n=='number') return true;
    return n!=='' && (typeof n=='string' || typeof n=='number') && !isNaN(Number(n));
}
function timestamp() {
    return +new Date()/1000;
}
function sleep(t) {
    return new Promise(resolve=>{
        setTimeout(resolve,t);
    });
}
function randint(min, max) { // min and max included 
	return Math.floor(Math.random() * (max - min + 1) + min);
}
function strip(s) {
	return s.replace(/\r?\n|\r/g,'');
}
function removeNewLine(s) {
	return s.replace(/(\r\n|\n|\r)/gm, "");
}
function instr(s,ar) {
	if(s)s = `${s}`.toLowerCase();
	for(let i=0;i<ar.length;i++) {
		if(typeof ar[i]=='string' && `${s}`.indexOf(ar[i].toLowerCase())!=-1) return true;
	}
}
function md5(data) {
	const crypto = require('crypto');
	return crypto.createHash('md5').update(data).digest("hex");
}
function parseJSON(str, val={},igerr=0) {
    if(str && typeof str=='object') return str;
    try{
      return JSON.parse(str)||val;
    }
    catch(e){
      if(!igerr)console.log(`\x1b[31m parseJSON:`,e,'-->',str,`\x1b[0m`);
      var ar;
      try{eval('ar='+str);return ar;}catch(e1){return val;}    
    }
}
function toDateText(tm) {
    var d;
    if(!tm) d=new Date();
    else if(isNum(tm)) d=new Date(parseFloat(`${tm}`.length>=12? tm:tm*1000));
    else if(typeof tm=='string') d=new Date(tm);
    else d=tm;
    return d.toLocaleString();
}
function plusSecond(n,tm) {
    const d = tm? new Date(`${tm}`.length>=12? parseFloat(tm):parseFloat(tm)*1000): new Date();
    d.setSeconds(d.getSeconds() +n);
    return d;
}
async function fetch_get(url, timeout = 10000, nocache = 0) {
    let config = {
        method: 'GET',
        timeout: timeout, // Timeout in milliseconds
    };

    if (nocache) {
        config.headers = {
            'Cache-Control': 'no-store',
            'Pragma': 'no-cache'
        };
    }

    try {
        const r = await axios(url, config);
        return r; // Axios response object
    } catch (e) {
        console.log(e);
		telegram(`fetch_get(${url}): ${e.message}`);
        // return false; // Uncomment if needed
    }
}
async function fetch_post(url, data,timeout=10000) {
	var r;
	try{
		const r = await axios.post(url, data, {
			timeout: timeout, // Timeout in milliseconds
			headers: {
				'Accept': 'application/json',
				'Content-Type': 'application/json'
			}
		});
	}
	catch(e){
		console.log(e);
		telegram(`fetch_post(${url}): ${e.message}`);
		//return false;
	}
	return r;
}
async function telegram(msg) {
	//if(msg.indexOf('tvbot:')==-1) msg='tvbot:'+msg;
	//var ip = await getServerIP();
	//msg+= `\n (${ip})`;
	return new Promise(async function(resolve, reject) {
		var token = process.env.telegram_token||cfg.telegram_token; 
		var chat_id = process.env.telegram_chatid||cfg.telegram_chatid;
		
		var api=`https://api.telegram.org/bot${token}/sendMessage`, res;
		res = await fetch_post(api,{
		  chat_id: chat_id, 
		  text: msg,
		  disable_notification: 0,
		  //parse_mode:'HTML',
		  disable_web_page_preview:false,
		});
		
		console.log('Telegram: '+msg)//console.log(api,await res.text())
		resolve(res? await res.json():{});
	}).catch(e=>{console.log(e)});
}
function fb_set(name,data) {
	return new Promise((resolve)=>{
		var url = `${cfg.fb_url}/${name}.json`;
		fetch(url, {
			method: "PUT",
			headers: {
				"Content-Type": "application/json"
			},
			body: JSON.stringify(data)
		})
		.then(response => response.json())
		.then(dt => resolve(dt))
		.catch(error => {
			console.error('Error:', error);
			telegram(`fb_set(${url}): ${error}`);
			resolve(0)
		});
	});
}
function fb_get(name) {
	return new Promise((resolve)=>{
		var url = `${cfg.fb_url}/${name}.json`;
		fetch(url)
		.then((response)=>{
			if (!response.ok) {
				throw new Error(`HTTP error! Status: ${response.status}`);
			}
			return response.json();
		})
		.then(data => resolve(data))
		.catch(error => {
			console.error('Error:', error);
			telegram(`fb_get(${url}): ${error}`);
			resolve()
		});
	});
}

var errFilters={}, logger;
function getStackTrace(msg='error') {
	try {
		var obj = {};
		Error.captureStackTrace(obj, getStackTrace);console.trace(msg);
		return obj.stack;
	}catch(e){}
}
function initTrackErrors() {

	process.on('uncaughtException', async function(err,source) {
	  console.log(`\x1b[31mCaught exception: ` + err.stack+'|'+source+`\x1b[0m`);
	  //clean old err
	  for(var id in errFilters) {
		if(timestamp() - errFilters[id] > 60) delete errFilters[id];
	  }
	  if(!instr(`${err.stack}`,['api.telegram.org','The user aborted a request'])) {
		var msg = '[withdraw]⛔ '+err.stack+'|'+source, id=md5(msg);
		msg+='->'+getStackTrace();
		
		if(!errFilters[id] ) {//|| timestamp()-errFilters[id]>60
		  errFilters[id] = timestamp();
		  //getLogger().error(toDateText()+': '+msg);
		  await telegram(msg);
		}
	  }
	});
	process.on("exit", async(code)=>{
		//_util.mark_processed(process.env.worker_name);
		telegram(`exit node app`);
	});
}
module.exports = {
	setVal,getVal,delVal,setValIfNot,
    isNum,sleep,randint,strip,removeNewLine,instr,telegram,fetch_get,fetch_post,parseJSON,md5,initTrackErrors,fb_set,fb_get,toDateText,plusSecond,timestamp,
}