const _fn = require('./func');

_fn.crawl_trend('XAUUSD');
